import 'package:flutter/material.dart';
import 'dart:async';

import 'package:presentation_displays_two/display_manager_two.dart';
import 'package:presentation_displays_two/presentation_displays_two.dart';
import 'package:presentation_displays_two/secondary_display_two.dart';

void main() {
  runApp(const MyApp());
}

// Add this function
void secondaryDisplayMain() {
  runApp(const SecondaryDisplayApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Presentation Displays Demo',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: '/',
      routes: {
        '/': (context) => const PresentationExample(),
        '/secondary': (context) => const SecondaryDisplayScreen(),
      },
    );
  }
}

class PresentationExample extends StatefulWidget {
  const PresentationExample({super.key});

  @override
  State<PresentationExample> createState() => _PresentationExampleState();
}

class _PresentationExampleState extends State<PresentationExample> {
  final DisplayManagerTwo _displayManager = DisplayManagerTwo();
  List<PresentationDisplaysTwo> _displays = [];

  @override
  void initState() {
    super.initState();
    _loadDisplays();
    _displayManager.setDataReceivedFromPresentationCallback((data) {
      print('Received data from presentation: $data');
    });
  }

  Future<void> _loadDisplays() async {
    try {
      final displays = await _displayManager.getDisplays(
        category: DISPLAY_CATEGORY_PRESENTATION,
      );
      setState(() {
        _displays = displays ?? [];
      });
    } catch (e) {
      print('Error loading displays: $e');
      // Handle the error, maybe show a snackbar to the user
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Presentation Example')),
      body: ListView(
        children: [
          for (final display in _displays)
            ListTile(
              title: Text('Display ${display.name}'),
              subtitle: Text('ID: ${display.displayId}'),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(Icons.cast),
                    onPressed: () => _showPresentation(display.displayId),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send),
                    onPressed: () => _sendDataToPresentation(display.displayId),
                  ),
                  IconButton(
                    icon: const Icon(Icons.hide_source),
                    onPressed: () => _hidePresentation(display.displayId),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Future<void> _showPresentation(int displayId) async {
    final result = await _displayManager.showSecondaryDisplay(
      displayId: displayId,
      routerName: '/secondary',
    );
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Show presentation: $result')),
    );
  }

  Future<void> _sendDataToPresentation(int displayId) async {
    final result = await _displayManager.sendDataToPresentation({
      'message': 'Hello from main display!',
      'timestamp': DateTime.now().toIso8601String(),
    });
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Send data to presentation: $result')),
    );
  }

  Future<void> _hidePresentation(int displayId) async {
    final result = await _displayManager.hideSecondaryDisplay(displayId: displayId);
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Hide presentation: $result')),
    );
  }
}

class PresentationScreen extends StatelessWidget {
  const PresentationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SecondaryDisplayTwo(
      callback: (data) {
        print('Received data in presentation: $data');
      },
      child: const Scaffold(
        backgroundColor: Colors.amber,
        body: Center(
          child: Text('This is the presentation screen'),
        ),
      ),
    );
  }
}

class SecondaryDisplayApp extends StatelessWidget {
  const SecondaryDisplayApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.amber,
        body: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Center(
                child: Text('This is the secondary display'),
              ),
              Center(
                child: Text('This is the secondary display'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SecondaryDisplayScreen extends StatelessWidget {
  const SecondaryDisplayScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Column(
        children: [
          Center(
            child: Text('This is the secondary display'),
          ),
          Center(
            child: Text('This is the secondary display'),
          ),
          Center(
            child: Text('This is the secondary display'),
          ),
        ],
      ),
    );
  }
}
